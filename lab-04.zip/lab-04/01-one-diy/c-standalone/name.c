int puts(const char *);

int main(void)
{
	puts("Hi, my name is TODO.\n");
	return 0;
}
