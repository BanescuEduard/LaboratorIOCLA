#ifndef STATE_H_
#define STATE_H_	1

void init_shopping(void);
extern const char *shopping_list[3];

#endif
